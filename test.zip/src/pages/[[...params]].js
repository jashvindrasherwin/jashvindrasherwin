/* eslint-disable jsx-a11y/alt-text */
import Header from "../components/header";
import Subheader from "../components/subheader";
import { useEffect, useState } from "react";

function DynamicPage() {
  const menuList = [
    {
      title: "Home",
      desc: "Welcome to MuseAI",
      icon: "fa fa-home",
      route: "home",
    },
    {
      title: "Training",
      desc: "Welcome to MuseAI Training",
      icon: "fa fa-check-square",
      route: "training",
    },
    {
      title: "Inspection",
      desc: "Welcome to MuseAI Inspection",
      icon: "fa fa-user",
      route: "inspection",
    },
  ];
  const [deviceWidth, setDeviceWidth] = useState(null);
  const [showMenu, setShowMenu] = useState(true);
  const [activeMenu, setActiveMenu] = useState('');
  const [selDesc, setSelDesc] = useState("");
  useEffect(() => {
    setDeviceWidth(window.innerWidth);
  }, []);

  const setMenuItem = (item) => {
    setActiveMenu(item.title);
    setSelDesc(item.desc);
  };

  const setMenu = () => {
    if (showMenu) {
      setShowMenu(false);
    } else {
      setShowMenu(true);
    }
  };

  return (
    <div className="main-container" id="page">
      <img
        src="/menuicon.png"
        className="desktopView barsMenu"
        alt="MuseAI"
        onClick={() => setMenu()}
      />
      <Header />
      <section id="hero1-2" className=" ">
        <div className="container vertical-center-rel"></div>
      </section>
      <div className="row">
        <Subheader />
      </div>
      <section id="team4-1" className="p-30 team p-a-0">
        <div className="row">
          {showMenu ? (
            <div className="col-md-2 col-sm-12 col-xs-12 divBorRight p-a-0 desktopView">
              <div style={{ height: deviceWidth }}>
                <div className="flex-container2 p-l menulist">
                  {menuList.map((item, index) => {
                    return (
                      <a key={index} href={`${item.route}`}>
                        <div
                          className={
                            "menulistItem cursor-pt " +
                            (activeMenu === item.title ? "active" : "")
                          }
                          onClick={() => setMenuItem(item)}
                        >
                          <i className={item.icon} aria-hidden="true"></i>
                          {item.title}
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : null}
          <div
            className={
              "col-sm-12 col-xs-12  p-a-0 " +
              (showMenu ? "col-md-10" : "col-md-12")
            }
          >
            <div className="text-center p-y-md">
              <h2 className="m-y-md ">Choose an option</h2>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 mb-10 cursor-pt">
                  <img
                    src="/images/artificial-intelligence.jpg"
                    className="imgBox"
                    alt="MuseAI"
                    style={{ margin: 20 }}
                  />
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 mb-10 cursor-pt">
                  <img
                    src="/images/artificial-intelligence.jpg"
                    className="imgBox"
                    alt="MuseAI"
                    style={{ margin: 20 }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="overlay111"></div>
    </div>
  );
}

export default DynamicPage;

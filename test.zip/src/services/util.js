import axios from "axios";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Util = {
  getHeader() {
    const header = {
      "content-type": "application/json, text/plain, */*",
      "Access-Control-Allow-Credentials": true,
      "Access-Control-Allow-Origin": "http://localhost:3000"
    };
    return header;
  },
  getApiPath(apiName) {
    const apiUrl = "https://donation.iskconvrindavan.com:8443/donations/getAllCategories";
    try {
      return typeof process.env.API === "undefined"
        ? apiUrl
        : process.env.API[apiName];
    } catch (err) {
      this.errorToast(err.message);
      return apiUrl;
    }
  },
  getMenuPath(apiName) {
    const apiUrl = "https://iskconmumbai.com/admin/web/menu.php";
    try {
      return typeof process.env.API === "undefined"
        ? apiUrl
        : process.env.API[apiName];
    } catch (err) {
      this.errorToast(err.message);
      return apiUrl;
    }
  },
  getRequest(url, data, notifyText) {
    const that = this;
    return new Promise((resolve, reject) => {
      axios({
        method: "get",
        url: data === null ? url : url + "?" + this.getSerializeParam(data),
        headers: this.getHeader(),
      })
        .then(function (response) {
          if (response["data"]["status"] === 4) {
            that.logout();
          } else if (response["data"]["status"] === 1) {
            that.successToast(notifyText);
          } else {
            that.errorToast(response["data"]["data"]);
          }
          resolve(response["data"]);
        })
        .catch((err) => {
          this.errorToast(err.message);
          reject(err.message);
        });
    });
  },
  postRequest(url, data, notifyText) {
    const that = this;
    return new Promise((resolve, reject) => {
      that.request("post", url, data, notifyText, resolve, reject);
    });
  },
  request(method, url, data, notifyText, resolve, reject) {
    const that = this;
    axios({
      method: method,
      url: url,
      data: that.getSerializeParam(data),
      headers: that.getHeader(),
    })
      .then(function (response) {
        if (response["data"]["status"] === 4) {
          that.logout();
        } else if (response["data"]["status"] === 1) {
          that.successToast(notifyText);
        } else {
          that.errorToast(response["data"]["data"]);
        }
        resolve(response["data"]);
      })
      .catch((err) => {
        that.errorToast(err.message);
        reject(err.message);
      });
  },
  getSerializeParam(obj) {
    const str = Object.keys(obj)
      .map(function (key) {
        return key + "=" + obj[key];
      })
      .join("&");
    return str;
  },
  successToast(message) {
    toast.success(message, {
      position: "top-right",
      autoClose: 1500,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: false,
      progress: undefined,
    });
  },
  errorToast(message) {
    toast.error(message, {
      position: "top-right",
      autoClose: 1500,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: false,
      draggable: false,
      progress: undefined,
    });
  },
  getFormattedDate() {
    const dateObj = new Date(new Date());
    const monthIndex = dateObj.getUTCMonth() + 1;

    const newdate = dateObj.getUTCDate();
    const year = dateObj.getUTCFullYear();
    const day = newdate < 10 ? "0" + newdate : newdate;
    const month = monthIndex < 10 ? "0" + monthIndex : monthIndex;
    return year + "-" + month + "-" + day;
  },
};

export default Util;

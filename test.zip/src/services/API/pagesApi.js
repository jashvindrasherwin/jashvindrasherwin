import Util from "../util";

const pagesApi = {
  getPath() {
    return Util.getApiPath();
  },
  donateCategoryApi(param) {
    const url = "https://donation.iskconvrindavan.com:8443/donations/getAllCategories";
    return Util.getRequest(url, param, null)
  },
  donateListApi(param) {
    const url = "https://donation.iskconvrindavan.com:8443/donations/getDonationList";
    return Util.getRequest(url, param, null)
  },
};

export default pagesApi;
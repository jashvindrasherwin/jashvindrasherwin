/* eslint-disable no-undef */

$(document).ready(function () {

    "use strict";


    /* =================================
       LOADER                     
    =================================== */
    // makes sure the whole site is loaded
    $(window).on('load', function () {

        // will first fade out the loading animation
        $(".loader-inner").fadeOut();
        // will fade out the whole DIV that covers the website.
        $(".loader").fadeOut("slow");

    });

    (function ($) {
        var size = $(document).width();


   
        // VERIFY WINDOW SIZE
        function windowSize() {
            size = $(document).width();
            if (size >= 991) {
                $('body').removeClass('open-menu');
                $('.hamburger-menu .bar').removeClass('animate');
            }
        };

        // ESC BUTTON ACTION
        $(document).keyup(function (e) {
            if (e.keyCode == 27) {
                $('.bar').removeClass('animate');
                $('body').removeClass('open-menu');
                $('header .desk-menu .menu-container .menu .menu-item-has-children a ul').each(function (index) {
                    $(this).removeClass('open-sub');
                });
            }
        });

        $('#cd-primary-nav > li').hover(function () {
            var $whidt_item = $(this).width();
            $whidt_item = $whidt_item - 8;

            var $prevEl = $(this).prev('li');
            var $preWidth = $(this).prev('li').width();
            var pos = $(this).position();
            pos = pos.left + 4;
            $('header .desk-menu .menu-container .menu>li.line').css({
                width: $whidt_item,
                left: pos,
                opacity: 1
            });
        });

        // ANIMATE HAMBURGER MENU
        $('.hamburger-menu').on('click', function () {
            $('.hamburger-menu .bar').toggleClass('animate');
            if ($('body').hasClass('open-menu')) {
                $('body').removeClass('open-menu');
            } else {
                $('body').toggleClass('open-menu');
            }
        });
        size = $(document).width();
        // $('header .desk-menu .menu-container .menu .menu-item-has-children ul').each(function(index) {
        //     $(this).append('<li class="back"><a href="#">Back</a></li>');
        // });

        // RESPONSIVE MENU NAVIGATION
        $('header .desk-menu .menu-container .menu .menu-item-has-children > a').on('click', function (e) {
            e.preventDefault();
            if (size <= 991) {
                $(this).next('ul').toggleClass('open-sub');
                $(this).toggleClass('active');
                not($(this).prev('ul')).removeClass('open-sub');
            }
        });

        // CLICK FUNCTION BACK MENU RESPONSIVE
        // $('header .desk-menu .menu-container .menu .menu-item-has-children ul .back').on('click', function(e) {
        //     e.preventDefault();
        //     $(this).parent('ul').removeClass('open-sub');
        // });

        $('body .over-menu').on('click', function () {
            $('body').removeClass('open-menu');
            $('.bar').removeClass('animate');
        });

        $(document).ready(function () {
            windowSize();

        });

        // $(window).scroll(function(){
        //     smallerMenu();
        // });

        $(window).resize(function () {
            windowSize();
        });

    })(jQuery);
    /* =================================
       NAVBAR COLLAPSE ON SCROLL
    =================================== */
    $(window).on('scroll', function () {
        var b = $(window).scrollTop();
        if (b > 60) {
            $(".navbar").addClass("top-nav-collapse");
        } else {
            $(".navbar").removeClass("top-nav-collapse");
        }
    });

    /* ===========================================================
   MAGNIFIC POPUP
============================================================== */
    $('.mp-singleimg').magnificPopup({
        type: 'image'
    });

    $('.mp-gallery').magnificPopup({
        type: 'image',
        gallery: { enabled: true },
    });

    $('.mp-iframe').magnificPopup({
        type: 'iframe'
    });



    /* =================================
       NAVBAR WITH TOP BAR
    =================================== */
    $('.nav-2').affix({
        offset: {
            top: $('.top-bar').height()
        }
    });
    /* ==========================================
       DATEPICKER
    ============================================= */
    if ($("#dfDate").length) {
        $('#dfDate').pickadate({
            min: new Date()
        });
    }


    /* ==========================================
       APPOINTMENT WITH DATEPICKER FORM
    ============================================= */
    $("#dateForm").on('submit', function (e) {
        e.preventDefault();
        var data = {
            name: $("#dfName").val(),
            email: $("#dfEmail").val(),
            phone: $("#dfPhone").val(),
            date: $("#dfDate").val(),
            message: $("#dfMessage").val()
        };

        if (isValidEmail(data['email']) && (data['name'].length > 1) && (data['date'].length > 1) && (data['message'].length > 1) && isValidPhoneNumber(data['phone'])) {
            $.ajax({
                type: "POST",
                url: "php/appointment.php",
                data: data,
                success: function () {
                    $('.success.df').delay(500).fadeIn(1000);
                    $('.failed.df').fadeOut(500);
                }
            });
        } else {
            $('.failed.df').delay(500).fadeIn(1000);
            $('.success.df').fadeOut(500);
        }

        return false;
    });


    /* ===========================================================
       PAGE SCROLLING FEATURE
    ============================================================== */
    $('a.smooth-scroll').on('click', function (event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top + 20
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });



    /* ===========================================================
       BACK TO TOP BUTTON
    ============================================================== */
    var offset = 300,
        //browser window scroll (in pixels) after which the "back to top" link opacity is reduced
        offset_opacity = 1200,
        //duration of the top scrolling animation (in ms)
        scroll_top_duration = 700,
        //grab the "back to top" link
        $back_to_top = $('.top');

    //hide or show the "back to top" link
    $(window).on('scroll', function () {
        ($(this).scrollTop() > offset) ? $back_to_top.addClass('is-visible') : $back_to_top.removeClass('is-visible fade-out');
        if ($(this).scrollTop() > offset_opacity) {
            $back_to_top.addClass('fade-out');
        }
    });

    //smooth scroll to top
    $back_to_top.on('click', function (event) {
        event.preventDefault();
        $('body,html').animate({
            scrollTop: 0
        }, scroll_top_duration
        );
    });



    /* ===========================================================
       HIDE MOBILE MENU AFTER CLICKING 
    ============================================================== */
    $('.navbar-nav>li>a:not(#dLabel)').on('click', function () {
        $('#navbar-collapse').removeClass("in").addClass("collapse");
    });



    /* ===========================================================
       FEATURES TAB
    ============================================================== */
    $('.features-tab .tab-title').on('click', function (e) {
        if (!$(this).hasClass('current')) {
            $('.tab-title').removeClass('out');
            $('.tab-title.current').addClass('out');
            $('.features-tab .tab-title').removeClass('current');
            $(this).addClass('current');
        }
        e.preventDefault();
    });





    /* ===========================================================
       GOOGLE MAPS
    ============================================================== */
    /* active mouse scroll when the user clicks into the map*/
    if ($('.map-container').length) {
        $('.map-container').on('click', function () {
            $('.map-iframe').css("pointer-events", "auto");
        });

        $(".map-container").on('mouseleave', function () {
            $('.map-iframe').css("pointer-events", "none");
        });
    }


    /* ==========================================
       FUNCTION FOR EMAIL ADDRESS VALIDATION
    ============================================= */
    function isValidEmail(emailAddress) {
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        return pattern.test(emailAddress);
    }


    /* ==========================================
       FUNCTION FOR PHONE NUMBER VALIDATION
    ============================================= */
    function isValidPhoneNumber(phoneNumber) {
        return phoneNumber.match(/[0-9-()+]{3,20}/);
    }


    /* ==========================================
       CONTACT FORM
    ============================================= */
    $("#contactForm").on('submit', function (e) {

        e.preventDefault();
        var data = {
            name: $("#cfName").val(),
            email: $("#cfEmail").val(),
            subject: $("#cfSubject").val(),
            message: $("#cfMessage").val()
        };

        if (isValidEmail(data['email']) && (data['message'].length > 1) && (data['name'].length > 1) && (data['subject'].length > 1)) {
            $.ajax({
                type: "POST",
                url: "php/contact.php",
                data: data,
                success: function () {
                    $('.success.cf').delay(500).fadeIn(1000);
                    $('.failed.cf').fadeOut(500);
                }
            });
        } else {
            $('.failed.cf').delay(500).fadeIn(1000);
            $('.success.cf').fadeOut(500);
        }

        return false;
    });
    /* ==========================================
       CALLBACK FORM
    ============================================= */
    $("#callbackForm").on('submit', function (e) {
        e.preventDefault();
        var data = {
            name: $("#cbName").val(),
            email: $("#cbEmail").val(),
            phone: $("#cbPhone").val()
        };

        if (isValidEmail(data['email']) && (data['name'].length > 1) && isValidPhoneNumber(data['phone'])) {
            $.ajax({
                type: "POST",
                url: "php/callback.php",
                data: data,
                success: function () {
                    $('.success.cb').delay(500).fadeIn(1000);
                    $('.failed.cb').fadeOut(500);
                }
            });
        } else {
            $('.failed.cb').delay(500).fadeIn(1000);
            $('.success.cb').fadeOut(500);
        }

        return false;
    });



    /* ===========================================================
       FUNFACTS COUNTER
    ============================================================== */
    if ($('.counter').length) {
        var o = $('.counter'),
            cc = 1;

        $(window).on('scroll', function () {
            var elemPos = o.offset().top,
                elemPosBottom = o.offset().top + o.height(),
                winHeight = $(window).height(),
                scrollToElem = elemPos - winHeight,
                winScrollTop = $(this).scrollTop();

            if (winScrollTop > scrollToElem) {
                if (elemPosBottom > winScrollTop) {
                    if (cc < 2) {
                        cc = cc + 2;
                        o.countTo();
                    }
                }
            }
        });
    }




    /* ==========================================
       DATEPICKER
    ============================================= */
    if ($("#dfDate").length) {
        $('#dfDate').pickadate({
            min: new Date()
        });
    }


    /* ===========================================================
       BOOTSTRAP FIX FOR IE10 in Windows 8 and Windows Phone 8  
    ============================================================== */
    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement('style');
        msViewportStyle.appendChild(
            document.createTextNode(
                '@-ms-viewport{width:auto!important}'
            )
        );
        document.querySelector('head').appendChild(msViewportStyle);
    }


}); // End $(document).ready Function
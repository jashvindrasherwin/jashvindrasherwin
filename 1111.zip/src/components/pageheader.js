import { useEffect, useState } from "react";
import $ from "jquery";

function PageHeader() {
 
  return (
    <>
      <header className="header bgtransparent bgwhite " id="header-sroll">
        <div className="">
          <div className="row">
            <div className="col-xs-12">
              <div className="desk-menu">
                <nav className="box-menu">
                  <div id="userProfile" className="headericonBgWar ">
                    <button className="btn btn-warning">Logout</button>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default PageHeader;

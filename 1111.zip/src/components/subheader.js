function Subheader() {

  return (
    <>
      <div className="col-md-12  col-sm-12 col-xs-12 headBox ">
        <div className="row">
          <div className="col-md-2 col-sm-12 col-xs-12 divBorRight headIcon p-a-0 ">
            <div className="flex-container ">
              <div>
                <i className="fa fa-home borLR" aria-hidden="true"></i>
              </div>
              <div>
                <i className="fa fa-comment borLR" aria-hidden="true"></i>
              </div>
              <div>
                <i className="fa fa-cog borLR" aria-hidden="true"></i>
              </div>
            </div>
          </div>
          <div className="col-md-10 col-sm-12 col-xs-12 headRightIcon p-a-0">
            <div className="flex-container3 p-rl-20">
              <div>
                <button type="button" className="btn btn-success iconSubWifiBg">
                  Wifi
                </button>
                <button
                  type="button"
                  className="btn btn-primary iconSubOtherBg"
                >
                  <i className="fa fa-refresh " aria-hidden="true"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-primary iconSubOtherBg"
                >
                  <i
                    className="fa fa-exclamation-circle "
                    aria-hidden="true"
                  ></i>
                </button>
                <button
                  type="button"
                  className="btn btn-primary iconSubOtherBg"
                >
                  <i className="fa fa-cog " aria-hidden="true"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-primary iconSubOtherBg"
                >
                  <i
                    className="fa fa-exclamation-circle "
                    aria-hidden="true"
                  ></i>
                </button>
                <select className="iconSuSelectBg" name="cars" id="cars">
                  <option value="">Select a MuseBox</option>
                  <option value="MuseBox A">MuseBox A</option>
                  <option value="MuseBox B">MuseBox B</option>
                  <option value="MuseBox C">MuseBox C</option>
                  <option value="MuseBox D">MuseBox D</option>
                </select>
                <button type="button" className="btn btn-danger iconSubPowerBg">
                  <i className="fa fa-power-off " aria-hidden="true"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Subheader;




import { useEffect, useState } from "react";

function LeftMenu() {
  const menuList = [
    { title: "Home", desc: "Welcome to MuseAI", icon: "fa fa-home" },
    {
      title: "Training",
      desc: "Welcome to MuseAI Training",
      icon: "fa fa-check-square",
    },
    {
      title: "Inspection",
      desc: "Welcome to MuseAI Inspection",
      icon: "fa fa-user",
    },
  ];
  const [deviceWidth, setDeviceWidth] = useState(null);
  const [activeMenu, setActiveMenu] = useState(menuList[0]["title"]);
   useEffect(() => {
     setDeviceWidth(window.innerWidth);
   }, []);

    const setMenuItem = (item) => {
      setActiveMenu(item.title);
    };

  return (
    <div style={{ height: deviceWidth }}>
      <div className="flex-container2 p-l menulist">
        {menuList.map((item, index) => {
          return (
            <div
              key={index}
              className={
                "menulistItem cursor-pt " +
                (activeMenu === item.title ? "active" : "")
              }
              onClick={() => setMenuItem(item)}
            >
              <i className={item.icon} aria-hidden="true"></i>
              {item.title}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default LeftMenu;
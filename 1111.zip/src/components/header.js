import { useEffect, useState } from "react";
import $ from "jquery";

function Header() {
  const [deviceWidth, setDeviceWidth] = useState(null);
  useEffect(() => {
    setDeviceWidth(window.innerWidth);
    initMenu();
  }, []);

  const initMenu = () => {
    setTimeout(function () {
      const size = $(document).width();

      $(".hamburgerMenu").on("click", function () {
        if (size <= 991) {
          $(".hamburgerMenu .bar").toggleClass("animate");
          if ($("body").hasClass("open-menu")) {
            $("body").removeClass("open-menu");
          } else {
            $("body").toggleClass("open-menu");
            var v = document.getElementById("userProfile");
            v.className += "hideIcon";
          }
        } else {
        }
      });

      $(
        "header .desk-menu .menu-container .menu .menu-item-has-children > a"
      ).on("click", function (e) {
        e.preventDefault();
        if (size <= 991) {
          $(
            "header .desk-menu .menu-container .menu .menu-item-has-children > a"
          )
            .not($(this))
            .removeClass("active");
          $(this).toggleClass("active");
        }
      });

      $("body .over-menu").on("click", function () {
        $("body").removeClass("open-menu");
        $(".bar").removeClass("animate");
      });
    }, 1000);
  };

  const closeHamburger = async () => {
    if (deviceWidth < 991) {
      $(".hamburgerMenu .bar").toggleClass("animate");
      $("body").toggleClass("open-menu");
    }
  };

  return (
    <>
      <header className="header bgtransparent bgwhite " id="header-sroll">
        <div className="">
          <div className="row">
            <div className="col-xs-12">
              <div className="desk-menu">
                <nav className="box-menu">
                  <div className="menu-container">
                    <div className="overlaybox">
                      <div className="menu-header-container">
                        <ul id="cd-primary-nav" className="menu">
                          <li className="menu-item " onClick={closeHamburger}>
                            <a href={"/home"}>Home</a>
                          </li>

                          <li className="menu-item" onClick={closeHamburger}>
                            <a href="/training">Training</a>
                          </li>
                          <li className="menu-item " onClick={closeHamburger}>
                            <a href="/inspection">Inspection</a>
                          </li>
                          <li className="menu-item" onClick={closeHamburger}>
                            <a href="/" className=" text-center">
                              Close
                            </a>
                          </li>
                          <li className="line"></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div className="hamburgerMenu mobileView">
                    <div className="bar"></div>
                  </div>
                  <div id="userProfile" className="headericonBg ">
                    <i className="fa fa-user iconBg" aria-hidden="true"></i>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;

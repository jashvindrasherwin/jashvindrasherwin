
const donationJSON = {
  title: 'ISKCON Vrindavan',
  donationList: [
    {
      "name": "Pujas",
      "route": "pujas",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "60faaf291ffa2947db6bbf86",
          "title": "Naivaidyam Seva ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210806081105-donationnaivedyam.jpg",
          "unit": null,
          "amount": "1100",
          "status": "NEW",
          "id": "610cee15e2770c5cc8c0cbf3"
        },
        {
          "categoryId": "60faaf291ffa2947db6bbf86",
          "title": "Panchopachar Puja ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210806080143-donationPanchopacharpuja.jpg",
          "unit": null,
          "amount": "2100",
          "status": "NEW",
          "id": "610cee2be2770c5cc8c0cbf4"
        },
        {
          "categoryId": "60faaf291ffa2947db6bbf86",
          "title": "Trividhi Seva ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210807064123-donationBlessingsfromBraj.jpg",
          "unit": null,
          "amount": "5100",
          "status": "NEW",
          "id": "610e2cd3e2770c5cc8c0cbf7"
        },
        {
          "categoryId": "60faaf291ffa2947db6bbf86",
          "title": "Recitation of  Bhagavad Gita",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210806081306-donationBG.jpg",
          "unit": null,
          "amount": "11000",
          "status": "NEW",
          "id": "610cee46e2770c5cc8c0cbf5"
        }
      ]
    },
    {
      "name": "Goshala",
      "route": "goshala",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Adopt a cow/bull for 1 year",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144411-WhatsApp Image 2021-06-09 at 12.45.36 PM (1).jpeg",
          "unit": null,
          "amount": "24000",
          "status": "NEW",
          "id": "6106a384e2770c5cc8c0cbe9"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Feed cow/bull for six months",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144507-WhatsApp Image 2021-06-09 at 12.45.35 PM.jpeg",
          "unit": null,
          "amount": "12000",
          "status": "NEW",
          "id": "6106a3f7e2770c5cc8c0cbea"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Feed a cow for three months",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144646-WhatsApp Image 2021-06-09 at 12.45.36 PM.jpeg",
          "unit": null,
          "amount": "6000",
          "status": "NEW",
          "id": "6106a48ae2770c5cc8c0cbeb"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Feed 10 Cows ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808125716-feed10couws.jpg",
          "unit": null,
          "amount": "700",
          "status": "NEW",
          "id": "610fd50f2caede3e39a517a1"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Feed 20 Cows ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808133807-feed20cows.jpg",
          "unit": null,
          "amount": "1400",
          "status": "NEW",
          "id": "610fdeac2caede3e39a517a3"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Feed 50 Cows ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808134046-feed50cows.jpg",
          "unit": null,
          "amount": "3500",
          "status": "NEW",
          "id": "610fdf0a2caede3e39a517a4"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Adopt a Cow/Bull for 1 month ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808135744-adopfor1month.jpg",
          "unit": null,
          "amount": "2000",
          "status": "NEW",
          "id": "610fe3192caede3e39a517a5"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Adopt a Cow/Bull for lifetime",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808140125-cowforlife.jpg",
          "unit": null,
          "amount": "240000",
          "status": "NEW",
          "id": "610fe55f2caede3e39a517a6"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor 2 trolleys of Grass",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210808141008-greengrass.jpg",
          "unit": null,
          "amount": "15000",
          "status": "NEW",
          "id": "610fe7cc2caede3e39a517a7"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor Barley Flour ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809055238-barleyflour.jpg",
          "unit": null,
          "amount": "1600",
          "status": "NEW",
          "id": "6110c4022caede3e39a517a8"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor Dried Grass ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809060232-driedgrass.jpg",
          "unit": null,
          "amount": "12000",
          "status": "NEW",
          "id": "6110c5622caede3e39a517a9"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor Dry Cakes ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809060445-drycakes.jpg",
          "unit": null,
          "amount": "2000",
          "status": "NEW",
          "id": "6110c75b2caede3e39a517aa"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor Jaggery ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809061312-jaggery.jpg",
          "unit": null,
          "amount": "650",
          "status": "NEW",
          "id": "6110c8d32caede3e39a517ab"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Sponsor medicine",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809061923-medecine.jpg",
          "unit": null,
          "amount": "2100",
          "status": "NEW",
          "id": "6110c9a62caede3e39a517ac"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": " 1 Day Maintenance of Goshala",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809062306-onedaysponsor.jpg",
          "unit": null,
          "amount": "32000",
          "status": "NEW",
          "id": "6110ca9c2caede3e39a517ad"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Wheat Bran (650Kgs)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210809062716-wheatbran.jpg",
          "unit": null,
          "amount": "9000",
          "status": "NEW",
          "id": "6110cbbe2caede3e39a517ae"
        },
        {
          "categoryId": "61028f39f855466e3e643fef",
          "title": "Adopt a Calf for Lifetime ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210812074817-cow+calfforlife.jpg",
          "unit": null,
          "amount": "360000",
          "status": "NEW",
          "id": "6114d2e07eba271c81d36675"
        }
      ]
    },
    {
      "name": "Festivals",
      "route": "festivals",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        
      ]
    },
    {
      "name": "Devotee Care",
      "route": "devotee-care",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Help feed the Vaishnavas",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210818050250-WhatsApp Image 2021-08-17 at 8.57.30 PM (3)-min.jpeg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "611c967d4a616c01b23f06dc"
        },
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Monthly General Medicine ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810082123-donations-site-generalmedicine.jpg",
          "unit": null,
          "amount": "4000",
          "status": "NEW",
          "id": "611237ffbb31ce24b5d184e8"
        },
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Sponsor day care for a devotee",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810073225-donations-site-1daydevoteecare.jpg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61122e55bb31ce24b5d184e3"
        },
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Sponsor a devotee's treatment ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810074532-donations-site-SPdiscipletreatment.jpg",
          "unit": null,
          "amount": "5001",
          "status": "NEW",
          "id": "61122f57bb31ce24b5d184e4"
        },
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Sponsor assisted living ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810075056-donations-site-assistedliving.jpg",
          "unit": null,
          "amount": "10000",
          "status": "NEW",
          "id": "61123695bb31ce24b5d184e7"
        },
        {
          "categoryId": "60faafb81ffa2947db6bbf88",
          "title": "Assisted living Facility ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810082606-donations-site-assisstedlivingfacility.jpg",
          "unit": null,
          "amount": "21000",
          "status": "NEW",
          "id": "61123904bb31ce24b5d184e9"
        }
      ]
    },
    {
      "name": "Temple Contribution",
      "route": "temple-contribution",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Rhode wireless microphone ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220125153139-751BCD47-D940-4FAA-957B-AE67E6BAE8A1_1_201_a.jpeg",
          "unit": null,
          "amount": "30000",
          "status": "NEW",
          "id": "61f0191f331b0345225a1c50"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "BoseSoundSystem for TempleHall",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220604060054-Bose-1.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "6299ae284179262702793ec6"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "BoseSoundSystem - BalaramHall",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220604060248-Bose-2.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "6299af5a4179262702793ec7"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "SoundSystem - PrabhupadSamadhi",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220604060505-Bose-3.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "629af6d54179262702793ee0"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "SoundSystem - Prabhupada House",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220604060848-Bose-4.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "629af7744179262702793ee1"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "LED Screen ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220604061153-Bose-5.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "629af7f34179262702793ee2"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Support 24 Hour Kirtan ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810083118-donations-site-24Hkirtan.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61123c05bb31ce24b5d184ea"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Srila Prabhupada House ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810090458-donations-site-SPhousejpg.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "6112426abb31ce24b5d184ef"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Srila Prabhupada Samadhi ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210811061216-donations-site-SPsamadhijpg.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61136b52bb31ce24b5d184f2"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Ladies Ashram ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810085456-donations-site-ladiesashram.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61124013bb31ce24b5d184ed"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Namhatta Preaching Center ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810090036-donations-site-namhatta.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61124120bb31ce24b5d184ee"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Support Bhishma Department ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810084319-donations-site-bhishmadepartment.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61123cf8bb31ce24b5d184eb"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Community Service Center",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210810084836-donations-site-communityservicejpg.jpg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61123ebfbb31ce24b5d184ec"
        },
        {
          "categoryId": "60fab0101ffa2947db6bbf89",
          "title": "Iskcon Vrindavan Broadcast",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813064111-WhatsApp Image 2021-08-11 at 12.46.31 (2).jpeg",
          "unit": null,
          "amount": "0",
          "status": "NEW",
          "id": "61136b66bb31ce24b5d184f3"
        }
      ]
    },
    {
      "name": "Deity Worship",
      "route": "deity-worship",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Mangal Aratik (4:30 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143539-WhatsApp Image 2021-06-09 at 12.46.36 PM.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61069ed3e2770c5cc8c0cbe2"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sringar Aratik (7:15 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143704-WhatsApp Image 2021-06-09 at 12.47.01 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "61069fd1e2770c5cc8c0cbe3"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Puspa Aratik (8:30am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143741-WhatsApp Image 2021-06-09 at 12.46.59 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a03ae2770c5cc8c0cbe4"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Raj Bhoga Aratik (12:00 pm )",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144003-WhatsApp Image 2021-06-11 at 12.53.31 PM.jpeg",
          "unit": null,
          "amount": "2001",
          "status": "NEW",
          "id": "6106a07ce2770c5cc8c0cbe5"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Utthapana Aratik (4:30 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144101-WhatsApp Image 2021-06-09 at 12.47.02 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a0f9e2770c5cc8c0cbe6"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sandhya Aratik (7:00 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144133-WhatsApp Image 2021-06-09 at 12.46.59 PM (1).jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "6106a1abe2770c5cc8c0cbe7"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sayana Aratik (8:30 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144232-WhatsApp Image 2021-06-09 at 12.47.00 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a231e2770c5cc8c0cbe8"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Mangal Bhoga (4:15 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813055737-WhatsApp Image 2021-08-11 at 12.46.31.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "6106465b16411d5a3c2b3144"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Naivedya Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814072126-WhatsApp Image 2021-08-14 at 12.17.25.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176f542e56a237161ea726"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Pratah Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813060548-WhatsApp Image 2021-08-11 at 12.46.31 (1).jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61160c2b2e56a237161ea71a"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Raj Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814071416-WhatsApp Image 2021-08-13 at 13.38.21.jpeg",
          "unit": null,
          "amount": "5555",
          "status": "NEW",
          "id": "61176dbe2e56a237161ea724"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Utthapana Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814071637-WhatsApp Image 2021-08-13 at 20.37.21-2.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176e392e56a237161ea725"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sandhya Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813060835-WhatsApp Image 2021-08-11 at 12.46.30.jpeg",
          "unit": null,
          "amount": "3001",
          "status": "NEW",
          "id": "61160c162e56a237161ea719"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sayana Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814072345-WhatsApp Image 2021-08-13 at 20.37.21.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176ff32e56a237161ea727"
        }
      ]
    },
    {
      "name": "Deity Care",
      "route": "deity-care",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Mangal Aratik (4:30 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143539-WhatsApp Image 2021-06-09 at 12.46.36 PM.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61069ed3e2770c5cc8c0cbe2"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sringar Aratik (7:15 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143704-WhatsApp Image 2021-06-09 at 12.47.01 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "61069fd1e2770c5cc8c0cbe3"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Puspa Aratik (8:30am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801143741-WhatsApp Image 2021-06-09 at 12.46.59 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a03ae2770c5cc8c0cbe4"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Raj Bhoga Aratik (12:00 pm )",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144003-WhatsApp Image 2021-06-11 at 12.53.31 PM.jpeg",
          "unit": null,
          "amount": "2001",
          "status": "NEW",
          "id": "6106a07ce2770c5cc8c0cbe5"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Utthapana Aratik (4:30 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144101-WhatsApp Image 2021-06-09 at 12.47.02 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a0f9e2770c5cc8c0cbe6"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sandhya Aratik (7:00 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144133-WhatsApp Image 2021-06-09 at 12.46.59 PM (1).jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "6106a1abe2770c5cc8c0cbe7"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sayana Aratik (8:30 pm)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144232-WhatsApp Image 2021-06-09 at 12.47.00 PM.jpeg",
          "unit": null,
          "amount": "1001",
          "status": "NEW",
          "id": "6106a231e2770c5cc8c0cbe8"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Mangal Bhoga (4:15 am)",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813055737-WhatsApp Image 2021-08-11 at 12.46.31.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "6106465b16411d5a3c2b3144"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Naivedya Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814072126-WhatsApp Image 2021-08-14 at 12.17.25.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176f542e56a237161ea726"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Pratah Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813060548-WhatsApp Image 2021-08-11 at 12.46.31 (1).jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61160c2b2e56a237161ea71a"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Raj Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814071416-WhatsApp Image 2021-08-13 at 13.38.21.jpeg",
          "unit": null,
          "amount": "5555",
          "status": "NEW",
          "id": "61176dbe2e56a237161ea724"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Utthapana Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814071637-WhatsApp Image 2021-08-13 at 20.37.21-2.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176e392e56a237161ea725"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sandhya Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210813060835-WhatsApp Image 2021-08-11 at 12.46.30.jpeg",
          "unit": null,
          "amount": "3001",
          "status": "NEW",
          "id": "61160c162e56a237161ea719"
        },
        {
          "categoryId": "60fac6f61ffa2947db6bbf8a",
          "title": "Sayana Bhoga ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210814072345-WhatsApp Image 2021-08-13 at 20.37.21.jpeg",
          "unit": null,
          "amount": "1501",
          "status": "NEW",
          "id": "61176ff32e56a237161ea727"
        }
      ]
    },
    {
      "name": "Anndana",
      "route": "anndana",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 20 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801144825-WhatsApp Image 2021-06-09 at 12.45.56 PM.jpeg",
          "unit": null,
          "amount": "800",
          "status": "NEW",
          "id": "6106a570e2770c5cc8c0cbed"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 30 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801145014-WhatsApp Image 2021-06-09 at 12.45.55 PM (1).jpeg",
          "unit": null,
          "amount": "1200",
          "status": "NEW",
          "id": "6106aa94e2770c5cc8c0cbee"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 40 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801145147-WhatsApp Image 2021-06-09 at 12.45.55 PM.jpeg",
          "unit": null,
          "amount": "1600",
          "status": "NEW",
          "id": "6106aadbe2770c5cc8c0cbef"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 100 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801145216-WhatsApp Image 2021-06-09 at 12.45.56 PM (1).jpeg",
          "unit": null,
          "amount": "4000",
          "status": "NEW",
          "id": "6106ab11e2770c5cc8c0cbf0"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 250 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801145255-WhatsApp Image 2021-06-09 at 12.45.56 PM (2).jpeg",
          "unit": null,
          "amount": "10000",
          "status": "NEW",
          "id": "6106ab52e2770c5cc8c0cbf1"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Feed 500 Brijwasis 1 Day",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210801145329-WhatsApp Image 2021-06-09 at 12.45.54 PM.jpeg",
          "unit": null,
          "amount": "20000",
          "status": "NEW",
          "id": "6106ab87e2770c5cc8c0cbf2"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Kichadi Prasad 1 day 1 time",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220404064257-Food-For-Life.jpg",
          "unit": null,
          "amount": "3200",
          "status": "NEW",
          "id": "624a965741792627027938b2"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Kichadi Prasad 1 day 2 times",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220404065652-Food For Life-2.jpg",
          "unit": null,
          "amount": "6400",
          "status": "NEW",
          "id": "624a984841792627027938b3"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": " Kichadi Prasad Seva 1 month ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220404070351-Food For Life-3.jpg",
          "unit": null,
          "amount": "99200",
          "status": "NEW",
          "id": "624a990441792627027938b4"
        },
        {
          "categoryId": "61028f68f855466e3e643ff0",
          "title": "Kichadi Prasad Seva 1 Year",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/220404070716-Food For Life-4.jpg",
          "unit": null,
          "amount": "1168000",
          "status": "NEW",
          "id": "624a995941792627027938b5"
        }
      ]
    },
    {
      "name": "Special Programs",
      "route": "special-programs",
      "image": "/images/other.jpg",
      "description": "<p>The Sri Sri Krishna Balaram Mandir, situated in the Raman Reti area of Vrindavan, holds a special significance for the devotees of the International Society for Krishna Consciousness. This grand temple represents the fulfilled dream of Srila Prabhupada, Founder Acharya of ISKCON, who wished to construct a temple of unparalleled beauty for the worship of the transcendental brothers Krishna and Balaram in the same village where They played more than five thousand years ago. Srila Prabhupada directly oversaw all the aspects of design and construction and personally called the Lord to come and accept the worship of His devotees from around the world. He said, “Lord Balaram is the source of spiritual strength, and I have built this temple just to give strength to the devotees”.</p><p>Today, the Sri Sri Krishna Balaram Mandir is a booming spiritual center. Every day of the week pilgrims flood in the gate in great numbers from all over the world. In fact, the large green government signs posted over the highway turn off to Vrindavan only give directions to two temples: Banke Bihari and ISKCON.</p>",
      "children": [
        {
          "categoryId": "61028f73f855466e3e643ff1",
          "title": "Your Day in Vrindavan ",
          "photoRefThumb": "https://donation.iskconvrindavan.com:8443/photos/download/210812083700-WhatsApp Image 2021-08-11 at 12.46.31 (3).jpeg",
          "unit": null,
          "amount": "21000",
          "status": "NEW",
          "id": "6114df417eba271c81d36678"
        }
      ]
    }
  ]
}

let iskconServices = donationJSON;

// if (typeof window !== "undefined") {
//   if (window.location.hostname === 'iskconagra.com') {
//     iskconServices = iskconAgra;
//   }
// }


export default iskconServices
/* eslint-disable jsx-a11y/alt-text */
import Header from "../components/header";
import Subheader from "../components/subheader";
import { useEffect, useState } from "react";
import React from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import faker from "faker";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

function Feedback() {
  const [arrayList, setArrayList] = useState([]);
  const [deviceWidth, setDeviceWidth] = useState(null);
  const [showMenu, setShowMenu] = useState(false);
  const [activeMenu, setActiveMenu] = useState("");

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
      title: {
        display: true,
        text: "Damage Percentage",
      },
    },
  };

  const labels = ["January", "February", "March", "April"];

  const data = {
    labels,
    datasets: [
      {
        label: "",
        data: labels.map(() => faker.datatype.number({ min: 0, max: 1000 })),
        backgroundColor: [
          "rgba(255, 99, 132, 0.2)",
          "rgba(54, 162, 235, 0.2)",
          "rgba(255, 206, 86, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(153, 102, 255, 0.2)",
          "rgba(255, 159, 64, 0.2)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",
        ],
      },
    ],
  };

  const menuList = [
    {
      title: "Home",
      desc: "Welcome to MuseAI",
      icon: "fa fa-home",
      route: "home",
    },
    {
      title: "Training",
      desc: "Welcome to MuseAI Training",
      icon: "fa fa-check-square",
      route: "training",
    },
    {
      title: "Inspection",
      desc: "Welcome to MuseAI Inspection",
      icon: "fa fa-user",
      route: "inspection",
    },
  ];

  useEffect(() => {
    loadArray();
    setDeviceWidth(window.innerWidth);
  }, []);

  const loadArray = () => {
    var data = [];
    var length = 8;
    for (var i = 0; i < length; i++) {
      data.push(i);
      setArrayList(data);
    }
  };
  const setMenuItem = (item) => {
    setActiveMenu(item.title);
  };

  const setMenu = () => {
    if (showMenu) {
      setShowMenu(false);
    } else {
      setShowMenu(true);
    }
  };

  return (
    <div className="main-container" id="page">
      <img
        src="/menuicon.png"
        className="desktopView barsMenu"
        alt="MuseAI"
        onClick={() => setMenu()}
      />
      <Header />
      <section id="hero1-2" className=" ">
        <div className="container vertical-center-rel"></div>
      </section>
      <div className="row">
        <Subheader />
      </div>
      <section id="team4-1" className="p-30 team p-a-0">
        <div className="row">
          {showMenu ? (
            <div className="col-md-2 col-sm-12 col-xs-12 divBorRight p-a-0 desktopView">
              <div style={{ height: deviceWidth }}>
                <div className="flex-container2 p-l menulist">
                  {menuList.map((item, index) => {
                    return (
                      <a key={index} href={`${item.route}`}>
                        <div
                          className={
                            "menulistItem cursor-pt " +
                            (activeMenu === item.title ? "active" : "")
                          }
                          onClick={() => setMenuItem(item)}
                        >
                          <i className={item.icon} aria-hidden="true"></i>
                          {item.title}
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : null}
          <div
            className={
              "col-sm-12 col-xs-12  p-a-0 " +
              (showMenu ? "col-md-10" : "col-md-12")
            }
          >
            {/* <div className="row">
              <div className="col-md-12 col-sm-12 col-xs-12 breadcum divBorBottom p-a-0 ">
                <p>
                  Muse Box{" "}
                  <span>
                    <i className="fa fa-chevron-right" aria-hidden="true"></i>
                  </span>{" "}
                  Select{" "}
                  <span>
                    <i className="fa fa-chevron-right" aria-hidden="true"></i>
                  </span>{" "}
                  Inspection{" "}
                  <span>
                    <i className="fa fa-chevron-right" aria-hidden="true"></i>
                  </span>{" "}
                  Summary
                </p>
              </div>
            </div> */}
            <div className="innerPage">
              <div className="">
                <div className="col-md-3 col-sm-12 col-xs-12 ">
                  <div className="innerSummaryBox">
                    <div className="text-center">
                      <h4>
                        SUMMARY
                        {/* <img src="/images/bar.png" alt="MuseAI" /> */}
                      </h4>
                    </div>
                    <div className="p-x-15 m-y">
                      <div className="row summaryBg">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Defect
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          Severity
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          Count
                        </div>
                      </div>

                      <div className="row summaryBgList">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Category A
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          Damage
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          5
                        </div>
                      </div>
                      <div className="row summaryBgList">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Category B
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          Damage
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          8
                        </div>
                      </div>
                      <div className="row summaryBgList">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Decay
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          &nbsp;
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          8
                        </div>
                      </div>
                      <div className="row summaryBgList">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Total Defective
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          &nbsp;
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          21
                        </div>
                      </div>
                      <div className="row summaryBgList">
                        <div className="col-md-4 col-sm-4 col-xs-4  text-left">
                          Total
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          &nbsp;
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-4  text-center">
                          21
                        </div>
                      </div>
                    </div>

                    <div className="innerGraphBox m-t-md m-b-md">
                      <div className="row">
                        <Bar options={options} data={data} />;
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-md-9 col-sm-12 col-xs-12 ">
                  <div className="col-md-12 col-sm-12 col-xs-12 innerPageBox">
                    {/* <div className="text-right">
                      <button className="btn btn-warning">Capture Image</button>
                      <button className="btn btn-warning">
                        Generate Report
                      </button>
                    </div> */}

                    <div className="col-md-12 col-sm-12 col-xs-12 pageTextBox">
                      <div className="row">
                        <div className="col-md-5 col-sm-5 col-xs-12 text-left">
                          <p className="">121-Inspection for Lime</p>
                        </div>
                        <div className="col-md-7 col-sm-7 col-xs-12 text-right">
                          <p className="">
                            Purchase order 9999999 and item no 10000000
                          </p>
                          <p className=" ">Sample no - 01</p>
                        </div>
                      </div>
                    </div>
                    <div className="row col-md-12 col-sm-12 col-xs-12 text-left">
                      <p className="captureHead">
                        Capture image for Sample no - 01
                      </p>
                    </div>
                    <div className="row m-b-md">
                      <div className="col-md-8">
                        <button
                          type="button"
                          className="btn btn-primary specialBtn m-r"
                        >
                          Capture Image
                        </button>

                        <button
                          type="button"
                          className="btn btn-primary specialBtn m-r"
                        >
                          New Sample
                        </button>

                        <select
                          className="iconSuSelectBg2"
                          name="cars"
                          id="cars"
                        >
                          <option value="">Sample...</option>
                          <option value="MuseBox A">MuseBox A</option>
                          <option value="MuseBox B">MuseBox B</option>
                          <option value="MuseBox C">MuseBox C</option>
                          <option value="MuseBox D">MuseBox D</option>
                        </select>
                      </div>
                      <div className="col-md-4 text-right">
                        <button
                          type="button"
                          className="btn btn-primary specialBtn"
                        >
                          Generate Report
                        </button>
                      </div>
                    </div>
                    <div className="col-md-12 col-sm-12 col-xs-12 innerPageBox">
                      <div className="row">
                        <div className="col-md-9 col-sm-9 col-xs-12">
                          <input
                            className=""
                            name="search"
                            id="search"
                            placeholder="Filter Images.."
                          />
                        </div>
                        <div className="col-md-3 col-sm-3 col-xs-12">
                          <p className="pagin text-right p-t-45">
                            <span>
                              <i
                                className="fa fa-chevron-left"
                                aria-hidden="true"
                              ></i>
                            </span>
                            1 2 3 4....
                            <span>
                              <i
                                className="fa fa-chevron-right"
                                aria-hidden="true"
                              ></i>
                            </span>
                          </p>
                        </div>
                      </div>
                      <div className="row">
                        {arrayList.map((item, index) => {
                          return (
                            <div
                              key={index}
                              className="col-md-3 col-sm-3 col-xs-6"
                            >
                              <div className=" bgBox">
                                <img
                                  src="/images/bg.png"
                                  alt="MuseAI"
                                  className="img-responsive"
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="overlay111"></div>
    </div>
  );
}

export default Feedback;

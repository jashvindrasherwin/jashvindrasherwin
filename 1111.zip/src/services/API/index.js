import pagesApi from './pagesApi';

// eslint-disable-next-line import/no-anonymous-default-export
export default {pagesApi }